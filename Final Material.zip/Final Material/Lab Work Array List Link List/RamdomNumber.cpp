#include <cstdlib>
#include <iostream>
using namespace std;

int main() {
	for (int x=0; x<15;x++)
 {
   int randomNumber = (rand() % 100);
   	insertNodeAtEnd(2);
  cout << randomNumber << endl;
}}
