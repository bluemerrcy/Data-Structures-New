#include<iostream>
using namespace std;
int main(){
    int x;
    x=10;
    for(int i=1; i<=10; i++){
        cout<<"786"<<endl;
    }
}