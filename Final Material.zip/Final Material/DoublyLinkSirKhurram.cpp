// Double Linked List Implementation
//KS.
#include<iostream>
using namespace std;
class node {
	public:
		node *next;
		node * previous;
		int data;

		node(int val) {
			data= val;
			next= previous=NULL;
		}
};

class DoubleLinkedList {
	private:
		node *head;
		int length;

	public:
		DoubleLinkedList() {
			head= NULL;
			length=0;
		}
		
	}
	
int main (){
	
	return 0;
}