#include<iostream>
using namespace std;
class node{
    public:
    int data;
    node*next;
    node(int valve){
        data=valve;
        next=NULL;
    }
};
class circular{
    public:
    node*head;
    int length;
    circular(){
        head=NULL;
        length=0;
    }
    void insert(int value){
        if(head==NULL){
            node*n=new node(value);
            head=n;
            head->next=head;
            return;
        }
        node*n=new node(value);
        node*temp=head;
        while(temp->next!=head){
            temp=temp->next;
        }
        n->next=head;
        head=n;
        temp->next=head;
        return;
    }
    // void deletion(int )
    void print(){
        node*temp;
        
        temp=head;
        while(temp->next!=head){
            cout<<temp->data;
            temp=temp->next;
        }
    }
    void deletion(){
        if(head==NULL){
            cout<<"nothing to delete";
            return;
        }
        node*temp=head;
        while(temp->next!=head){
            temp=temp->next;
        }
        head=head->next;
        temp->next=head;
    }
};
int main(){
    circular obj1;
    obj1.insert(5);
    obj1.insert(5);
    obj1.insert(5);
    obj1.insert(5);
    obj1.insert(5);
    obj1.deletion();
    obj1.deletion();
    obj1.deletion();
    // obj1.insert(5);
    obj1.print();
};