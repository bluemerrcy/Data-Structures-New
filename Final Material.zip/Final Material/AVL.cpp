#include<iostream>
using namespace std;
class node{
	public:
		node *left;
		node*right;
		int data;
		int height;
		node(int data)
		{
			this->data=data;
			height=0;
			left=right=NULL;
		}
};
class AVLtree{
	private:
	node*root;
	void makeEmpty(node* t);
	node* insert(int x,node*t);
	node* singleleftrotate(node* &C);
	node* singlerightrotate(node*&C);
	
	node* doubleleftrightrotate(node* &C);
	node* doublerightleftrotate(node* &C);
	
	node*findmin(node*t);
	node*findmax(node *t);
	
	node *remove(int x,node*t);
	int height(node*t);
	int getBalance(node*t);
	void inorder(node *t);
	
	public:
		AVLtree()
		{
			root=NULL;
		}
		void insert(int x){
			root=insert(x,root);
		}
		void remove(int x)
		{
			root=remove(x,root);
		}
		void display()
		{
			inorder(root);
			cout<<endl;
		}

	
};

int main()
{
	AVLtree tree;
	tree.insert(3);
	tree.insert(4);
	tree.insert(5);
	tree.insert(6);
	tree.insert(7);
	tree.display();
	return 0;
}

node* AVLtree::singleleftrotate(node* &A)
{
node* newRoot = A->right;
A->right = newRoot->left;
newRoot->left = A;
A->height = max(height(A ->left), height(A ->right)) + 1;
newRoot ->height = max(height(newRoot->right), A->height) + 1;
return newRoot;
}

node* AVLtree::singlerightrotate(node* &C)
{
node* newRoot = C->left;
C->left = newRoot->right;
newRoot->right = C;
C->height = max(height(C ->left), height(C ->right)) + 1;
newRoot ->height = max(height(newRoot->left), C->height) + 1;
return newRoot;
}

node* AVLtree::doubleleftrightrotate(node*& t)
{
t->left = singleleftrotate(t->left);
return singlerightrotate(t);
}

node* AVLtree::doublerightleftrotate(node*& t)
{
t->right = singlerightrotate(t->right);
return singleleftrotate(t);
}

void AVLtree::inorder(node *t)
{
	if(t==NULL)
	return;
	inorder(t->left);
	cout<<t->data<<" ->";
	inorder(t->right);
}
int AVLtree::height(node* t)
{
	return(t==NULL ? -1 : t->height);
}
int AVLtree::getBalance(node*t)
{
	if(t==NULL)
	return 0;
	else 
	return height(t->left) - height(t->right);
}
	
	
node *AVLtree::findmin(node *t)
{
	if(t==NULL)
	return NULL;
	else if(t->left==NULL)
		return  t;
	else 
		return findmin(t->left);
}

node *AVLtree::findmax(node *t)
{
	if(t==NULL)
    	return NULL;
	else if(t->right==NULL)
		return  t;
	else 
		return findmax(t->right);
}
void AVLtree::makeEmpty(node* t) {
        if(t == NULL)
            return;
        makeEmpty(t->left);
        makeEmpty(t->right);
        delete t;
    }
	
node*  AVLtree::  insert(int x, node* t)
    {
        if(t == NULL)
        {
            t = new node (x);
        }
        else if(x < t->data)
        {
            t->left = insert(x, t->left);
            if(height(t->left) - height(t->right) == 2)
            {
                if(x < t->left->data)
                    t = singlerightrotate(t);
                else
                    t = doubleleftrightrotate(t);
            }
        }
        else if(x > t->data)
        {
            t->right = insert(x, t->right);
            if(height(t->right) - height(t->left) == 2)
            {
                if(x > t->right->data)
                    t = singleleftrotate(t);
                else
                    t = doublerightleftrotate(t);
            }
        }

        t->height = max(height(t->left), height(t->right))+1;
        return t;
    }
   
    node* AVLtree::remove(int x, node* t)
    {
        node* temp;

        // Element not found
        if(t == NULL)
            return NULL;

        // Searching for element
        else if(x < t->data)
            t->left = remove(x, t->left);
        else if(x > t->data)
            t->right = remove(x, t->right);

        // Element found
        // With 2 children
        else if(t->left && t->right)
        {
            temp = findmin(t->right);
            t->data = temp->data;
            t->right = remove(t->data, t->right);
        }
        // With one or zero child
        else
        {
            temp = t;
            if(t->left == NULL)
                t = t->right;
            else if(t->right == NULL)
                t = t->left;
            delete temp;
        }
        if(t == NULL)
            return t;

        t->height = max(height(t->left), height(t->right))+1;

        // If node is unbalanced
        // If left node is deleted, right case
        if(height(t->left) - height(t->right) == 2)
        {
            // right right case
            if(height(t->left->left) - height(t->left->right) == 1)
                return singleleftrotate(t);
            // right left case
            else
                return doublerightleftrotate(t);
        }
        // If right node is deleted, left case
        else if(height(t->right) - height(t->left) == 2)
        {
            // left left case
            if(height(t->right->right) - height(t->right->left) == 1)
                return singlerightrotate(t);
            // left right case
            else
                return doubleleftrightrotate(t);
        }
        return t;
    }