#include <iostream>
using namespace std;

class IntBinaryTree
{
private:
	struct TreeNode{
		int value;
		TreeNode *left;
		TreeNode *right;
	};
	TreeNode *root;
           
    // void tree_clear(TreeNode* nodeptr)
    // {
	// if (nodeptr != NULL)	{
	//     tree_clear( nodeptr->left ); 
	//     tree_clear( nodeptr->right );
	//     delete nodeptr;   
	// }
    // }
	void tree_clear(TreeNode *&);
	void deleteNode(int, TreeNode *&);
	void makeDeletion(TreeNode *&);
	void displayInOrder(TreeNode *);
public:
        IntBinaryTree()		// Constructor
		{ root = NULL; }
	// ~IntBinaryTree()	// Destructor
	// 	{ tree_clear(root); }
        // void tree_clear(TreeNode* nodeptr);
	void insertNode(int);
	bool searchNode(int);
	void remove(int);
	void showNodesInOrder(void)
		{	displayInOrder(root); }
};
bool IntBinaryTree::searchNode(int num)
{
	TreeNode *nodePtr = root;

	while (nodePtr)
	{
		if (nodePtr->value == num)
			return true;
		else if (num < nodePtr->value)
			nodePtr = nodePtr->left;
		else
			nodePtr = nodePtr->right;
	}
	return false;
}
void IntBinaryTree::makeDeletion(TreeNode *&nodePtr)
{
	TreeNode *tempNodePtr;	// Temporary pointer, used in
	                      // reattaching the left subtree.

	if (nodePtr == NULL)
		cout << "Cannot delete empty node.\n";
	else if (nodePtr->right == NULL)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->left; // Reattach the left child
		delete tempNodePtr;
	}
    	else if (nodePtr->left == NULL)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->right; // Reattach the right child
		delete tempNodePtr;
	}
	// If the node has two children.
	else
	{
		// Move one node the right.
		tempNodePtr = nodePtr->right;
		// Go to the end left node.
		while (tempNodePtr->left)
			tempNodePtr = tempNodePtr->left;
		// Reattach the left subtree.
		tempNodePtr->left = nodePtr->left;
		tempNodePtr = nodePtr;
		// Reattach the right subtree.
		nodePtr = nodePtr->right;
		delete tempNodePtr;
	}
}

  

void IntBinaryTree::deleteNode(int num, TreeNode *&nodePtr)
{
	if (num < nodePtr->value)
		deleteNode(num, nodePtr->left);
	else if (num > nodePtr->value)
		deleteNode(num, nodePtr->right);
	else
		makeDeletion(nodePtr);
}

void IntBinaryTree::displayInOrder(TreeNode *nodePtr)
{
	if (nodePtr)
	{
		displayInOrder(nodePtr->left);
		cout<< nodePtr->value << endl;
		displayInOrder(nodePtr->right);
	}
}

void IntBinaryTree::insertNode(int num)
{
	TreeNode *newNode,	// Pointer to a new node
	         *nodePtr;	// Pointer to traverse the tree

	// Create a new node
	newNode = new TreeNode;
	newNode->value = num;
	newNode->left = newNode->right = NULL;

	if (!root)	// Is the tree empty?
		root = newNode;
	else
	{
		nodePtr = root; 
        		while (nodePtr != NULL)
		{      if (num < nodePtr->value)
			{      if (nodePtr->left)
					nodePtr = nodePtr->left;
				else
				{     nodePtr->left = newNode;
					break;
				}
			}
			else if (num > nodePtr->value)
			{      if (nodePtr->right)
					nodePtr = nodePtr->right;
				else
				{      nodePtr->right = newNode;
					break;
				}
			}
			else
			{   cout << "Duplicate value found in tree.\n";
		            break;
			}
		}		
	}
}


int main()
{
	IntBinaryTree tree;

	cout << "Inserting nodes.\n";
	tree.insertNode(5);
	tree.insertNode(8);
	tree.insertNode(3);
	tree.insertNode(12);
	tree.insertNode(9);
	if (tree.searchNode(3))
		cout << "3 is found in the tree.\n";
	else
		cout << "3 was not found in the tree.\n";

    // IntBinaryTree tree;

	// cout << "Inserting nodes. ";
	// tree.insertNode(5);
	// tree.insertNode(8);
	// tree.insertNode(3);
	// tree.insertNode(12);
	// tree.insertNode(9);
	// cout << "Done.\n";
}
