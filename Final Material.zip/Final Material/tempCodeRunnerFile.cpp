~IntBinaryTree()	// Destructor
	// 	{ tree_clear(root); }